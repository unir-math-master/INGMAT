function [puntos, solaprox, t, iter] = disparosecante_nodirichlet(funcion, a, b, alfa, beta, N, tol, maxiter)
% [puntos, solaprox, t, iter] = disparosecante_nodirichlet('sistema', 2, 3, 1/4, 1/3+log(3), 30, 1e-7, 50)

    h = (b-a)/(N+1);
    x = a:h:b;
    
    t0=0;
    [x,y] = ode45(funcion, x, [alfa, t0]');
    yb0 = y(end, 1); 
    
    t1 = (beta - alfa)/(b-a); %t1=1;
    [x, y] = ode45(funcion, x, [t1, (t1-alfa)/2]');
    yb1 = y(end,1);
    
    iter = 1;
    incre = tol+1;
    
    while incre>tol && iter<maxiter
        %Sirve para encontrar los ceros de una funcion de forma iterativa
        t = t1 - (t1-t0)*(ypb1-beta)/(ypb1-ypb0); %t = t1 - (t1-t0)*(yb1-beta)/(yb1-yb0);
        [x, y] = ode45(funcion, x, [t, (t- alfa)/2]');
        incre = abs(y(end, 1) - beta);
        
        iter = iter+1;
        t0 = t1;
        t1 = t;
        yb0=yb1;
        yb1=y(end,1);
    end
    
    if incre<tol
        puntos = x;
        solaprox = y;
    else
        disp('se necesitan mas iteraciones')
    end
end
