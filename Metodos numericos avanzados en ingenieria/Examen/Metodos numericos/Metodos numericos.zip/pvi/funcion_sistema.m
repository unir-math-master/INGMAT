function [du] = funcion_sistema(t,u)
    du(1) = u(2);
    du(2) = 3.*exp(t).*(cos(t)-sin(t))-u(1)-u(4);
    du(3) = u(4);
    du(4) = u(4)-u(3);
    du = du(:);
end
