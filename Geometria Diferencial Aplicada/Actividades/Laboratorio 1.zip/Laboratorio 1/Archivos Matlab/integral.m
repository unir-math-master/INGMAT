clear
syms t

f = sqrt(50)*sqrt(1 + (2/25)*t^2);
int(f)