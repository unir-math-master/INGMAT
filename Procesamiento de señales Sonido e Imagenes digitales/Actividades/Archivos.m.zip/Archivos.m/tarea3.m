clear
clc

%Aproximacion numerica de la FT
inct = 0.01;
t = [0:inct:6];
fs = 1/inct;
T = 6;
N = T/inct;

x0 = 0;
x1 = 2;
x = x0.*(t<2.9)+x1.*((t>=2.9)&(t<=3))+x0.*(t>3);

subplot(1,4,1);
S = plot(t,x)
grid on;
axis([0 6 -0.5 2.5])
S.LineWidth = 1.5;
title("X1(t)") 
xlabel("t")
ylabel("x(t)")

X1 = fft(x)/fs;
wn = 2*pi*(-fs/2:fs/N:fs/2);
incw = 2*pi*fs/N;

subplot(1,4,2);
S = plot(wn,abs(fftshift(X1)));
S.LineWidth = 1.5;
grid on;

subplot(1,4,3);
plot(wn,angle(fftshift(X1)));
grid on;

x0 = ifft(X1)/inct;
wn = (wn+fs*3);
wn = wn*T/length(wn);

subplot(1,4,4);
S = plot(wn,x0)
axis([0 6 -0.5 2.5])
S.LineWidth = 1.5;
grid on;
