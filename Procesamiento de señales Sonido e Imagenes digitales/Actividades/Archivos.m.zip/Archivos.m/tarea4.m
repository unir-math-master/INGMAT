clear;
clc;

T=6;

inct=0.01;
t=0:inct:T;
fs=1/inct;
N=T/inct; % Definimos el número de muestras
wn=2*pi*(-fs/2:fs/N:fs/2);
x = 0.*(t<2.9)+2.*((t>=2.9)&(t<=3))+0.*(t>3);

media = mean(x)


xf = (1/N).*fft(x);
xf(1)

% Calculamos FFT
xf = fft(x) ;
% Segun la ecuacion de analisis DFT X[m] para m=0 es
X_0= sum(x);
% Dividimos entre fs para ajustar la amplitud de la FFT y que se corresponda con la amplitud real de la FT
xf = xf/N;



% Potencia de la señal
P = trapz(wn, abs(fft(x)/fs).^2) / (2*pi);

% Energia de la señal
E = trapz(t, abs(x).^2);

X1 = fft(x)/fs
X1_recortada = X1(2:601);
X1_flip = fliplr(X1_recortada);
X1_conj = conj(X1_flip);
sum(X1_recortada-X1_conj)

subplot(1,3,1);
plot(t,x)
xlabel('t');
ylabel('x_1(t)');
title('x_1(t)');


X1=fft(x)/fs; % Calculamos la FFT y dividimos entre fs para ajustar la amplitud de la FFT y que se corresponda con la amplitud real de la FT
wn=2*pi*(-fs/2:fs/N:fs/2); % Definimos el eje de frecuencias centrado
incw=2*pi*fs/N; % Mínimo incremento frecuencial (entre muestras contiguas)

subplot(1,3,2);
plot(wn,abs(fftshift(X1))); % Representamos la FT

