clear;

T=2.9-2.5;

inct=0.01;
t=2.5:inct:2.9;
fs=1/inct;
N=T/inct; % Definimos el número de muestras
x= 0.*(t<2.9)+2.*((t>=2.9)&(t<=3))+0.*(t>3);

X1=fft(x)/fs; 
wn=2*pi*(-fs/2:fs/N:fs/2); 
incw=2*pi*fs/N;

subplot(1,3,1);
S = plot(t,x)
xlabel('t');
ylabel('x_1(t)');
title('x_1(t)');
S.LineWidth = 1.5;
grid on

subplot(1,3,2);
S =plot(wn,abs(fftshift(X1)));
S.LineWidth = 1.5;
grid on

subplot(1,3,3);
S = plot(wn,angle(fftshift(X1)));
S.LineWidth = 1.5;
grid on