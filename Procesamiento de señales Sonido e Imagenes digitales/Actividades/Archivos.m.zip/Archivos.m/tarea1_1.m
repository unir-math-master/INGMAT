clear 
clc

%Calculo de DTFS
%c = (1/N)fft(x)
%x = N*ifft(C)

%{
%x1[n]
subplot(1,5,1);
n0 = [0:5];
n1=[-6:-1];
x0 = exp(-j*(pi/3)*n0);
x1 = exp(-j*(pi/3)*n1);

N1 = 6 % pi/3 = 2*pi/N1 
S = stem([n1 n0],[x1 x0]);
S.LineWidth = 1.5;
S.Marker = 'diamond';
S.MarkerFaceColor = 'red';
title("x1[n]") 
xlabel("n")
ylabel("x[n]")
grid on

%Re(x1[n])
subplot(1,5,2);

c0 = (1/N1)*fft(x0);
c0=0+round(c0*10^10)/10^10
c1 = (1/N1)*fft(x1);
c1=0+round(c1*10^10)/10^10

hold on
S = stem([n1 n0], [real(c1) real(c0)])
S.LineWidth = 1.5;
S.Marker = 'diamond';
S.MarkerFaceColor = 'red';

title("Re(C1m)") 
xlabel("m")
ylabel("Cm")
grid on

%Im(x1[n])
subplot(1,5,3);
S = stem([n1 n0],[imag(c1) imag(c0)])
S.LineWidth = 1.5;
S.Marker = 'diamond';
S.MarkerFaceColor = 'red';
title("Im(C1m)") 
xlabel("m")
ylabel("Cm")
grid on

%Modulo(x1[n])
subplot(1,5,4);
S = stem([n1 n0],[abs(c1) abs(c0)])
S.LineWidth = 1.5;
S.Marker = 'diamond';
S.MarkerFaceColor = 'red';
title("Abs(C1m)") 
xlabel("m")
ylabel("Cm")
grid on

%(x1[n])
subplot(1,5,5);
S = stem([n1 n0],[angle(c1) angle(c0)])
S.LineWidth = 1.5;
S.Marker = 'diamond';
S.MarkerFaceColor = 'red';
title("Ang(C1m)") 
xlabel("m")
ylabel("Cm")
grid on
%}


%x2[n]
subplot(1,5,1);
n2=[0:3];
n3=[-4:-1]

x2 = [2 2 2 0];
x3 = [2 2 2 0];

N2 = 4 % Definido por el modulo
S = stem([n3 n2],[x3 x2]);
S.LineWidth = 1.5;
S.Marker = 'diamond';
S.MarkerFaceColor = 'red';
title("x2[n]") 
xlabel("n")
ylabel("x[n]")
grid on

%Re(x2[n])
subplot(1,5,2);
c2 = (1/N2)*fft(x2);
c3 = (1/N2)*fft(x3);

S = stem([n3 n2],[real(c3) real(c2)])
S.LineWidth = 1.5;
S.Marker = 'diamond';
S.MarkerFaceColor = 'red';
title("Re(C2m)") 
xlabel("m")
ylabel("Cm")
grid on

%Im(x2[n])
subplot(1,5,3);
S = stem([n3 n2],[imag(c3) imag(c2)])
S.LineWidth = 1.5;
S.Marker = 'diamond';
S.MarkerFaceColor = 'red';
title("Im(C2m)") 
xlabel("m")
ylabel("Cm")
grid on

%(x2[n])
subplot(1,5,4);
S = stem([n3 n2],[abs(c3) abs(c2)])
S.LineWidth = 1.5;
S.Marker = 'diamond';
S.MarkerFaceColor = 'red';
title("Abs(C2m)") 
xlabel("m")
ylabel("Cm")
grid on

%(x2[n])
subplot(1,5,5);
S = stem([n3 n2],[angle(c3) angle(c2)])
S.LineWidth = 1.5;
S.Marker = 'diamond';
S.MarkerFaceColor = 'red';
title("Ang(C2m)") 
xlabel("m")
ylabel("Cm")
grid on