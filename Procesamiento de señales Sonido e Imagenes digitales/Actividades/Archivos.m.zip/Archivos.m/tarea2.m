clear
clc

%Calculo de FT 
%A mano

n = [0:5];
a = [2, exp(-j*pi/2), 2*exp(j*pi), 1, 2*exp(j*pi), exp(-j*pi/2)]
N=6;
x = N*ifft(a);
M = mean(x);

%{
hold on;
S = stem(n,x);
S.LineWidth = 1.5;
S.Marker = 'diamond';
S.MarkerFaceColor = 'red';
T = stem(n,a);
T.LineWidth = 1.5;
T.Marker = 'diamond';
T.MarkerFaceColor = 'green';
U = plot([0 5],[M M]);
U.LineWidth = 1.5
U.Color = 'magenta';
xlabel("n");
ylabel("x[n]");
legend("Señal Original", "Coeficientes", "Media")
grid on;
%}

%Parseval
E1 = (1/N).*(x.^2);
E1 = sum(E1)
E2 = (a.^2);
E2 = sum(E2)
%Voltios al cuadrado

%Graficos de señal original
%{
subplot(1,3,1);
S = stem(n,x)
S.LineWidth = 1.5;
S.Marker = 'diamond';
S.MarkerFaceColor = 'red';
title("N*ifft(a)") 
xlabel("n")
ylabel("x[n]")
grid on

subplot(1,3,2);
S = stem(n,real(x))
S.LineWidth = 1.5;
S.Marker = 'diamond';
S.MarkerFaceColor = 'red';
title("Re(x[n])") 
xlabel("n")
ylabel("x[n]")
grid on

subplot(1,3,3);
S = stem(n,imag(x))
S.LineWidth = 1.5;
S.Marker = 'diamond';
S.MarkerFaceColor = 'red';
title("Im(x[n])") 
xlabel("n")
ylabel("x[n]")
grid on
%}

%Graficos de coeficientes
subplot(1,3,1);
S = stem(n,a)
S.LineWidth = 1.5;
S.Marker = 'diamond';
S.MarkerFaceColor = 'red';
title("a[n]") 
xlabel("n")
ylabel("a[n]")
grid on

subplot(1,3,2);
S = stem(n,real(a))
S.LineWidth = 1.5;
S.Marker = 'diamond';
S.MarkerFaceColor = 'red';
title("Re(x[n])") 
xlabel("n")
ylabel("x[n]")
grid on

subplot(1,3,3);
S = stem(n,imag(a))
S.LineWidth = 1.5;
S.Marker = 'diamond';
S.MarkerFaceColor = 'red';
title("Im(x[n])") 
xlabel("n")
ylabel("x[n]")
grid on
%}
