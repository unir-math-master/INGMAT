
public class Tablon  {
	private String dato = "";
        private int numLectores=0;
        private int numEscritores=0;
	public Tablon () {
		
	}
	
	public synchronized void permisoLeer () {
           try{
            while (numEscritores>0 || dato.equals("")){
                wait();
            }
            numLectores++;
            }catch (InterruptedException e){
                
            }
        }
        
        public synchronized String dejarLeer () {
		numLectores--;
                notifyAll();
                return dato;
	}
        
        public synchronized void permisoEscribir (String _dato) {
            try{
		while (numLectores >0 ||numEscritores>0 )
                    wait ();
                numEscritores++;
                dato=_dato;
            }catch (InterruptedException e){
                
            }
        }
        
        public synchronized void dejarEscribir () {
		numEscritores=0;
                notifyAll();
	}
	
	
}