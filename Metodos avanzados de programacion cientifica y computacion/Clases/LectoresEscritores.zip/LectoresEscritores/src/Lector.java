
public class Lector extends Thread {
	private int id;
	private String dato;
        private Tablon tablon;
	public Lector (int _id, Tablon _tablon) {
		id=_id;
                tablon=_tablon;
	}
	
	public void run () {
                int idL=id+1;
		System.out.println ("El lector "+idL+" quiere leer");
		tablon.permisoLeer();
		System.out.println ("El lector "+idL+" esta leyendo");
		dato=tablon.dejarLeer();
		System.out.println ("El lector "+idL+" ha leido"+dato);
	}
}