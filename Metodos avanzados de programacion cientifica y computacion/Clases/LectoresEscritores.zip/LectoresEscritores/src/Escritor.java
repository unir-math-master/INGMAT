


public class Escritor extends Thread {
	private int id;
        private String dato;
        private Tablon tablon;
	public Escritor (int _id, String _dato, Tablon _tablon) {
		id=_id;
                dato=_dato;
                tablon=_tablon;
	}
	
	public void run () {
		System.out.println ("El escritor "+id+" quiere escribir");
		tablon.permisoEscribir(dato);
		System.out.println ("El escritor "+id+" escribiendo "+dato);
		tablon.dejarEscribir();
                System.out.println ("El escritor "+id+" ha escrito");
	}
}
		
		