/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.*;
/**
 *
 * @author mluisadiez
 */
public class LectoresEscritores {
    static public Tablon tablon=new Tablon();
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        for (int  i=0; i<10; i++){
            if (new Random().nextInt()%2==0){
                new Lector(i, tablon).start();
                System.out.println("se ha creado el Lector"+i);
            }else{
                new Escritor(i,String.valueOf(new Random().nextLong()), tablon).start();
                System.out.println("se ha creado el Escritor"+i);
            }
        }
    }
    
}
