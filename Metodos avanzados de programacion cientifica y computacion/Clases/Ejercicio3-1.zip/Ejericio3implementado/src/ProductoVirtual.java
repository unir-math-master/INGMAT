
public class ProductoVirtual extends Producto {

	String version;
	public ProductoVirtual(int idProducto, String _version) {
	
		super(idProducto);
		version=_version;
	}
	
	@Override
	public void visualizar(){
	      System.out.printf("%-30s", "Identificador producto");
	      System.out.printf("%-30s", "Version");
	      
	      System.out.println();
	      System.out.printf("%-30d", id);
	      System.out.printf("%-30s", version);
	   
	  }
	   

}
