import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;




public class Main {
	//se crea la empresa
	static Empresa miEmpresa;
	
	//este  es el flujo de entrada
    static Scanner flujoEntrada=new Scanner(System.in);
    
    /**
     * esta funcion pide  los datos del producto que se va a nsertar en el almacen
     * @param idProducto
     * @return Producto
     */
    public static Producto obtenerNuevoProducto(){
        String entrada;
        
        Producto tempProducto=null;
        int opcion;
        //pide los datos del producto
        System.out.println("Para insertar un producto, teclee:\n 1-Producto Físico \n 2-Producto virtual");
        opcion=flujoEntrada.nextInt();
        if (opcion==1){
            System.out.println("Inserte peso del producto");
            float peso=flujoEntrada.nextFloat();
            System.out.println("Inserte alto del producto");
            float alto=flujoEntrada.nextFloat();
            System.out.println("Inserte ancho del producto");
            float ancho=flujoEntrada.nextFloat();
            System.out.println("Inserte largo del producto");
            float largo=flujoEntrada.nextFloat();
            System.out.println("Inserte coste transporte del producto");
            float ctransporte=flujoEntrada.nextFloat();
            System.out.println("Inserte stock del producto");
            int stock=flujoEntrada.nextInt();
            System.out.println(miEmpresa.getNumProductos()+"1");
            //el id se asigna al insertarlo en el almacen
            tempProducto=new ProductoFisico(-1,peso,alto,ancho,largo,ctransporte,stock);
        }else{
            System.out.println("Inserte versión del producto");
            String version=flujoEntrada.next();
            
           //el id se asigna al isnertarlo en el almacen
            tempProducto=new ProductoVirtual(-1,version);
        }
        return tempProducto;
      
    }
    
    /**
     * Esta  funcion sirve pasa  simular  la compra
     * No se crea un pedido, solo se  implementa  los que se pide en el ejerccio 3
     * Consultar la  solucion completa facilitada
     */
    public static void comprar(){
        Producto productoSeleccionado=null;
        int idProducto;
        System.out.println("Indique  el identificador del producto que quiere comprar");
        
        idProducto=flujoEntrada.nextInt();
            
          productoSeleccionado=miEmpresa.getProducto(idProducto);
           while (productoSeleccionado==null) {
            System.out.println("El producto no existe");
            
            System.out.println("Indique  el identificador del producto que quiere comprar");
            
            idProducto=flujoEntrada.nextInt();
           productoSeleccionado=miEmpresa.getProducto(idProducto);
           //esto se podría  haber tratado con excepciones
           }
           
        System.out.println("Inserte cantidad que quiere comprar");
            int cantidad=flujoEntrada.nextInt();
         
        //aquí se debería añadir  el producto  comprado a un pedido como  se habíaa tratado en el ejercicio 2
        
            miEmpresa.quitarStockProducto(idProducto, cantidad);
        }
    
    public static boolean seguirComprando(){
        System.out.println("¿Quiere comprar otro producto?  S/N");
           String si=flujoEntrada.next();
           if (si.equals("S")||si.equals("s")) return true;
           else return false;
   }
	   
	    /**
	     * @param args the command line arguments
	     */
	    public static void main(String[] args) throws IOException{
	    	
	    	
	    	 System.out.println("Indique el número  de productos que quiere insertar.");
	    	 
	    	 int numProductos=flujoEntrada.nextInt();
	    	 //como se va a usar un array  se necesita saber el tamaño que se le va a dar. Poco  eficiente
	        
	       miEmpresa=new Empresa(numProductos);
	      
	        //se rellena el almacen  y  a cada producto se le asignacomo id  su posición. El problema
	        //surge si no se insertan así habría que asegurarse de que  quedan huecos  libres en el almacen
	        for (int i=0; i<numProductos;i++){
	            Producto producto=obtenerNuevoProducto();
	            miEmpresa.insertarProducto(producto);
	            System.out.println("Producto añadido.\nTiene "+miEmpresa.getNumProductos()+" productos");
	        };
	        
	        //un  ejemplo
	        if (miEmpresa.getNumProductos()<miEmpresa.maxNumProductos()) {
	        	Producto producto=obtenerNuevoProducto();
	        	miEmpresa.insertarProducto(producto);
	        }
	       
	        System.out.println("***************************************************************************");
	        System.out.println("***************************************************************************");
	        System.out.println();
	        System.out.println();
	       
	        System.out.println("***************************************************************************");
	        System.out.println("***************************************************************************");
	        System.out.println("***************************************************************************");
	        System.out.println();
	        System.out.println();
	      
	        System.out.println("***************************************************************************");
	        System.out.println("Los productos disponibles son:");
	        //lista los productos en el almacen
	         miEmpresa.listarProductos();
	         System.out.println("***************************************************************************");
	        System.out.println();
	        do{
	            comprar();
	            
	       
	        }while(seguirComprando());
	        System.out.println("***************************************************************************");
	        System.out.println("***************************************************************************");
	        System.out.println("***************************************************************************");
	        System.out.println();
	        System.out.println();
	       
	        //prueba de añadir stock
	        System.out.println("Indique el número  de producto  al que quiere añadir stock.");
	    	 
	    	 int numP=flujoEntrada.nextInt();
	    	  System.out.println("Indique la cantidad que  quiere añadir.");
		    	 
		    	 int cantidad=flujoEntrada.nextInt();
		    	 miEmpresa.aniadirStockProducto(numP,cantidad);
	        
		    	 System.out.println("Los productos disponibles son:");
		    	 miEmpresa.listarProductos();
	         
	        System.exit(0);
	        
	        
	        
	    }
	    
	}




