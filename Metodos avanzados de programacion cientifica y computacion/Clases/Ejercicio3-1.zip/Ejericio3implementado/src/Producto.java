

abstract public class Producto {

 protected int id;

    
    public Producto(int _id){
       id=_id;
    }
  
    public int getId(){
        return id;
    }
    public void setId(int _id){
        id=_id;
    }
    abstract public void visualizar();
    
}
