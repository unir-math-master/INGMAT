
import java.util.Scanner;


public class ProductoFisico extends Producto {

	  private float peso;

	  private float alto;

	  private float ancho;

	  private float largo;
	  
	  private float costeTransporte;

	  private  int  stock;
  
    public ProductoFisico(int _id,float _peso, float _alto, float _ancho, float _largo, float _costeTransporte,int _stock){
      super(_id);
      peso=_peso;
      alto=_alto;
      ancho=_ancho;
      largo=_largo; 
      costeTransporte=_costeTransporte;
      stock=_stock;
      
    }
   
  
  
     
    

  public void aniadirStock(int cantidad) {
      stock+=cantidad;
  }

  public void quitarStock(int cantidad) {
      stock-=cantidad;
  }
  
  @Override
  public void visualizar(){
      System.out.printf("%-30s", "Identificador producto");
      System.out.printf("%-10s", "Peso");
      System.out.printf("%-10s", "Alto");
      System.out.printf("%-10s", "Ancho");
      System.out.printf("%-10s", "Largo");
      System.out.printf("%-20s", "Coste Transporte");
      System.out.printf("%-10s", "Stock");
      System.out.println();
      System.out.printf("%-30d", id);
      System.out.printf("%-10.2f", peso);
      System.out.printf("%-10.2f", alto);
      System.out.printf("%-10.2f", ancho);
      System.out.printf("%-10.2f", largo);
      System.out.printf("%-20.2f", costeTransporte);
      System.out.printf("%-10d", stock);
  }

}
