
import java.util.ArrayList;
import java.util.HashMap;


public class Empresa {

	
   private int numProductos=0;;  
   /**
   * 
   * @element-type Producto
   */
    
  private Producto[]  almacen;
    /**
   * 
   * @element-type Cliente
   */
  
 public Empresa(int numProductos){
	 //crea el almacen con tamaño fijo
     almacen=new Producto[numProductos];
     
 }
 public int getNumProductos(){
	 //obtiene el numero de productos en el almacen
     return almacen.length;
 }
 
 public int maxNumProductos(){
	 //obtiene el numero de productos en el almacen
     return numProductos;
 }
 
 public Producto getProducto(int idProducto){
	 Producto pr;
	 if (idProducto<almacen.length) {
		  pr=almacen[idProducto];
	 }
	 else pr=null;
     
  
     return pr;
 }
 
 private int buscarIdLibre() {
	
	 for (int i=0;i<almacen.length;i++) {
		 if  (almacen[i]==null) {
			 
			 return i;
		 }
	 }
	 return -1;
 }
 
 public void insertarProducto(Producto producto){
	  //crea un producto, su id se debe de asignar  y es el indice del array donde se va a guardar
     //esto  es un problema  porque si se eliminase un producto se quedarían huecos  en el array , si se recuperan los huecos moviendo los productos
     //se deberían cambiar los identificcadores de los productos  que se han modvido de sitio, sino no se podrían buscar por el indice, pero esto
     //no está bien, esto es  un problema  por usar array
	 
     int idProducto=buscarIdLibre();
     if (idProducto!=-1) {
    	 producto.setId(idProducto);
    	 almacen[idProducto]= producto;
     
     numProductos++;
     } else 
    	 System.out.println("El almacen esta lleno");
    
     
 }

  public void aniadirStockProducto(int idProducto, int cantidad) {
      // llama a una funcion  de producto que  añada stock
      if (almacen.length>idProducto){
          Producto pr=almacen[idProducto];
          // se debe hacer una conversion a ProductoFisico porque esa función no está sobrecargada en la jerarquía
          if (pr instanceof ProductoFisico)((ProductoFisico)almacen[idProducto]).aniadirStock(cantidad);
        //si todos tienen sstock se quitaría el if-else
          else System.out.println("Los productos virtuales no tienen stock");
      }
      
      //si se considera que stock y la funcion  es de todos los productos y se pone  el  atributo  en la base  y se sobrecarga 
      //la funcion  en la jerarquia
      //almacen[idProducto].aniadirStock(cantidad)
     
  }

  public void quitarStockProducto(int idProducto, int cantidad) {
	// llama a una funcion  de producto que  quite stock
      if (almacen.length>idProducto){
          Producto pr=almacen[idProducto];
       // se debe hacer una conversion a ProductoFisico porque esa función no está sobrecargada en la jerarquía
          if (pr instanceof ProductoFisico)((ProductoFisico)almacen[idProducto]).quitarStock(cantidad);
          //si todos tienen stock se quitaría el if-else
          else System.out.println("Los productos virtuales no tienen stock");
          
          //si se considera que stock y la funcion  es de todos los productos y se pone  el  atributo  en la base  y se sobrecarga 
          //la funcion  en la jerarquia
          //almacen[idProducto].quitarStock(cantidad)
      }
  }
  
  
  
  public void listarProductos(){
      
      for (int i=0; i<almacen.length;i++) {
       almacen[i].visualizar();
       System.out.println();
       }
  }
  
}
