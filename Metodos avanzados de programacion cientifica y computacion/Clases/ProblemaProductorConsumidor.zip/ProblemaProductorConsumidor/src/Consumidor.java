/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mluisadiez
 */


class Consumidor implements Runnable {
	private Buffer buffer;
	
	public Consumidor(Buffer _buffer) {
		buffer = _buffer;
	} // constructor ConsumidorPilaRunnable (Pila)

	// redefinimos el metodo run ()
	public void run () {
		int elementoAExtraer;
		int tiempoEspera;
		
		for (int i = 0; i < 20; i++) {
			// genero aleatoriamente un tiempo de espera entre 1 y 50 milisegundos
			tiempoEspera = (int) Math.round (Math.random () * 50) + 1;
	
			elementoAExtraer = buffer.sacarElemento ();
			System.out.println ("Acaba de salir el elemento: " + elementoAExtraer);
			
			try {
				Thread.sleep (tiempoEspera);
			} // try
			catch (InterruptedException e) {
				System.err.println ("Se ha producido una excepción: " + e.toString ());
			} // catch
			
		} // for
	} // run ()
	
} // ConsumidorPilaRunnable


