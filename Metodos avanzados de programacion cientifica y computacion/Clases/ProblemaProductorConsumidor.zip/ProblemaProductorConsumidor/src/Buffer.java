/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mluisadiez
 */
class Buffer {
	private final int CAPACIDAD_MAXIMA= 1024;
	
	private int [] info= new int [CAPACIDAD_MAXIMA];
	private int cima;
	private int maximo;
		
	public Buffer (int capacidad) {
		maximo= capacidad;
		
		for (int i = 0; i < CAPACIDAD_MAXIMA; i++) {
			info[i] = 0;
		} // for
		
		cima= -1;
	} // constructor Pila (long)
	
	public synchronized void insertarElemento (int elemento) {
		while (cima >= maximo - 1) {
			try {
				System.out.println ("No se puede añadir nada");
				wait ();
				System.out.println ("Ya se puede volver a añadir");
			}
			catch (InterruptedException e) {
				System.err.println ("Se ha producido un error: " + e.toString ());
			} // catch
		} // while
		
		cima++;
		info[cima] = elemento;
		
		notifyAll ();
	} 
	
	public synchronized int sacarElemento () {
		int elem;
		
		while (cima == -1) {
			try {
				System.out.println ("No se puede sacar nada");
				wait ();
				System.out.println ("Ya se puede volver a sacar");
			}
			catch (InterruptedException e) {
				System.err.println ("Se ha producido un error: " + e.toString ());
			} // catch
		} // while
		
		elem = info[cima];
		cima--;
		
		notifyAll ();
		
		return (elem);
	} // sacarElemento

	
} // Pila
	
