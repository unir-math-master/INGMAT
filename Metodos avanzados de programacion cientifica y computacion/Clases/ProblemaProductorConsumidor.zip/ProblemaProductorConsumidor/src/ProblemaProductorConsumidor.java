/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author mluisadiez
 */
public class ProblemaProductorConsumidor {

        static Buffer buffer;
	static Productor productorRunnable_;
	static Consumidor consumidorRunnable_;
    /**
     * @param args the command line arguments
     */
   
        
	public static void main (String [] args) {
		buffer= new Buffer (10);
		productorRunnable_ = new Productor (buffer);
		consumidorRunnable_ = new Consumidor (buffer);
		
		Thread productorThread = new Thread (productorRunnable_);
		Thread consumidorThread = new Thread (consumidorRunnable_);
		
		productorThread.start ();
		try {
			Thread.sleep (15);
		}
		catch (InterruptedException e) {
			System.err.println ("Se ha producido un error: " + e.toString ());
		} // catch
		
		consumidorThread.start ();
		
	} // main ()

    }
    

