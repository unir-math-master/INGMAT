/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mluisadiez
 */

import java.lang.Math;

class Productor implements Runnable {
	private Buffer buffer;
	
	public Productor (Buffer _buffer) {
		buffer= _buffer;
	} // constructor ProductorPilaRunnable (Pila)

	// redefinimos el metodo run ()
	public void run () {
		int elementoAInsertar;
		int tiempoEspera;
		
		for (int i = 0; i < 20; i++) {
			// genero aleatoriamente un número entero entre 0 y 500
			elementoAInsertar = (int) Math.round (Math.random () * 500);
			// genero aleatoriamente un tiempo de espera entre 1 y 20 milisegundos
			tiempoEspera = (int) Math.round (Math.random () * 20) + 1;
	
			buffer.insertarElemento (elementoAInsertar);
			System.out.println ("Se acaba de insertar el elemento: " + elementoAInsertar);
			
			try {
				Thread.sleep (tiempoEspera);
			} // try
			catch (InterruptedException e) {
				System.err.println ("Se ha producido una excepción: " + e.toString ());
			} // catch
			
		} // for
	} // run ()
	
} // ProductorPilaRunnable

