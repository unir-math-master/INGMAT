package ejercicio5;

public class Circulo extends FiguraCurva {
	private  double radio;
	public Circulo(String color, int x, int y,int _radio) {
		super(color, x, y);
		radio=_radio;
		
		// TODO Auto-generated constructor stub
	}

	@Override
	public void dibujar() {
		// TODO Auto-generated method stub
		

	}

	@Override
	public double calcularArea() {
		// TODO Auto-generated method stub
		return Math.PI*Math.pow(radio, 2);
	}

	@Override
	public double calcularLongitud() {
		// TODO Auto-generated method stub
		return 2*Math.PI*radio;
	}

}
