package ejercicio5;

public abstract class Poligono extends Figura {
	protected int numlados;
        
	public Poligono(String color,int _numlados){
        super(color);
       
        numlados=_numlados;
        
    }
	

}
