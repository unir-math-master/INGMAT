/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio5;

/**
 *
 * @author mluisadiez
 */
public abstract class Figura {
	protected  String color;
	protected Lienzo lienzo;
	   
    public Figura(String _color){
        color=_color;
    }
    public void setColor(String  _color) {
    	color=_color;
    }
    public abstract void dibujar();
    public abstract double calcularArea();
    public abstract double calcularLongitud();
}
