package ejercicio5;

public class TrianguloEscaleno extends Triangulo {
	private double lado1;
	private double lado2;
	private double lado3;
	
	
	public TrianguloEscaleno(String color, byte x, byte y, int numlados,double _lado1,double  _lado2,double _lado3) {
		super(color, x, y, numlados);
		lado1=_lado1;
		lado2=_lado2;
		lado3=_lado3;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void dibujar() {
		// TODO Auto-generated method stub

	}

	@Override
	public double calcularArea() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double calcularLongitud() {
		// TODO Auto-generated method stub
		return 0;
	}

}
