package ejercicio5;

public class TrianguloEquilatero extends Triangulo {
	private double lado;

	public TrianguloEquilatero(String color, byte x, byte y, int numlados,double _lado) {
		super(color, x, y, numlados);
		lado=_lado;
		// TODO Auto-generated constructor stub
	}
	@Override
	public void dibujar() {
		

	}

	@Override
	public double calcularArea() {
		double base=lado;
		double altura=Math.sqrt(Math.pow(lado, 2)-Math.pow(lado/2,2));
		return base*altura/2;
	}

	@Override
	public double calcularLongitud(){
		// TODO Auto-generated method stub
		return lado*3;
	}
}
