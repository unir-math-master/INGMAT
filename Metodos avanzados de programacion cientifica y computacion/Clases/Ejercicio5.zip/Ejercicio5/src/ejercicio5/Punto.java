package ejercicio5;

public class Punto {
	private int x;
	private int y;
	
	public Punto(int _x, int _y) {
		x = _x;
		y = _y;
	}
	
	public int getX() {
		return x;
	}
	
	public int getY() {
		return y;
	}

	

}
