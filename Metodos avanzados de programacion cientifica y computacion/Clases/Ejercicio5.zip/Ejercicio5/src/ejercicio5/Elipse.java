package ejercicio5;

public class Elipse extends FiguraCurva {
	private double semiejeMayor;
	private double semiejeMenor;

	public Elipse(String color, int x, int y) {
		super(color, x, y);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void dibujar() {
		// TODO Auto-generated method stub

	}

	@Override
	public double calcularArea() {
		// TODO Auto-generated method stub
		return Math.PI*semiejeMayor*semiejeMenor;
	}

	@Override
	public double calcularLongitud() {
		// TODO Auto-generated method stub
		double e=Math.sqrt(semiejeMayor*semiejeMayor+semiejeMenor*semiejeMenor)/2;
		return 2*Math.PI*e;
	}

}
