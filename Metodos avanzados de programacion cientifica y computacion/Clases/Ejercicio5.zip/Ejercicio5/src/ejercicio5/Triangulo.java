package ejercicio5;

public abstract class Triangulo extends Poligono {
	protected Punto verticeSuperior;

	public Triangulo(String color,  int x, int y,int numlados) {
		super(color,numlados);
		verticeSuperior=new Punto(x,y);
		// TODO Auto-generated constructor stub
	}

}
