/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio5;
import java.util.Scanner;
/**
 *
 * @author mluisadiez
 */
public class Ejercicio5 {
	
	static Scanner flujoEntrada=new Scanner(System.in);
        static Tablero tablero;

	static int pedirX() {
		int x = -1;
		do {
			System.out.print("\nInserte coordenada X entre 1 y 28 ");
			x = flujoEntrada.nextInt();
		} while(x < 0 || x > 29);
		return x;
	}
	
	static int pedirY() {
		int y = -1;
		do {
			System.out.print("\nInserte coordenada Y entre 1 y 58: ");
			y = flujoEntrada.nextInt();
		} while(y < 0 || y > 59);
		return y;
	}
	
	static void mostrarMenu() {
		System.out.println("Indique la opcion que quiere llevar  a cabo");
		System.out.println("1. Insertar un  rectangulo");
                System.out.println("2. Insertar un  cuadrado");
		System.out.println("0. No insertar más figuras");
		System.out.print("Elija opcion: ");
	}
	
	static void insertarRectangulo() {
		System.out.println("Inserta vertice noroeste");
                int vNOx=pedirX();
                System.out.println("Inserta vertice noroeste");
                int vNOy=pedirY();
                int  maxAncho=30-vNOx-1;
                int maxAlto=60-vNOy-1;
                System.out.println("Inserta un valor de ancho menor que "+maxAncho);
                int ancho=flujoEntrada.nextInt();
                System.out.println("Inserta un valor de alto menor que "+maxAlto);
                int alto=flujoEntrada.nextInt();
                System.out.println("Inserta un color:R(rojo), A(amarillo), V(verde), B(azul) ");
                String color=flujoEntrada.next();
                tablero.insertarFigura(new Rectangulo(color,vNOx,vNOy,4,ancho,alto));
		
		}
        
        	static void insertarCuadrado() {
		System.out.println("Inserta vertice noroeste");
                int vNOx=pedirX();
               
                int vNOy=pedirY();
                int  maxAncho=30-vNOx-1;
                int maxAlto=60-vNOy-1;
                int maxLado;
                if (maxAncho<maxAlto) maxLado=maxAncho;
                else maxLado=maxAlto;
                System.out.println("Inserta un valor de lado menor que "+maxLado);
                int lado=flujoEntrada.nextInt();

                System.out.println("Inserta un color: R(rojo), A(amarillo), V(verde), B(azul) ");
                String color=flujoEntrada.next();
                tablero.insertarFigura(new Cuadrado(color,vNOx,vNOy,4,lado));
		
		
	}

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    	int opcion = -1;
        System.out.println("Inserte  el número máximo de posibles figuras en el tablero");
        int numFiguras=flujoEntrada.nextInt();
        int numInsertadas=0;
    	tablero=new Tablero(numFiguras);
       
    	do {
            mostrarMenu();
            opcion = flujoEntrada.nextInt();
            switch (opcion) {
    				case 0:
    					System.out.println("Tablero de figuras");
                                        
                                        tablero.dibujarFiguras();
    					break;
    				case 1:
                                        if (numInsertadas!=numFiguras){
    					insertarRectangulo();numInsertadas++;
                                        }
                                        else
                                        {System.out.println  ("Ha insertado el máximo de figuras en el tablero"); tablero.dibujarFiguras();opcion=0;}
    					break;
    				case 2:
                                        if (numInsertadas!=numFiguras){
    					insertarCuadrado();
                                        numInsertadas++;
                                        }
                                        else {System.out.println  ("Ha insertado el máximo de figuras en el tablero"); tablero.dibujarFiguras();;opcion=0;}
    					break;
    				default:
    					System.out.println("\nOpcion invalida");
    
                            }
        }while(opcion!=0 || numInsertadas!=numFiguras);
    	
    		
    	System.exit(0);
    	}
}
    
    

