package ejercicio5;

public abstract class Cuadrilatero extends Poligono {
	protected Punto verticeNO;

	public Cuadrilatero(String color, int x, int y, int numlados) {
		super(color, numlados);
		 verticeNO=new Punto(x,y);
		// TODO Auto-generated constructor stub
	}



}
