package ejercicio5;

public class Lienzo {
	private final int filas = 30;
	private final int columnas = 60;
	private  int[][] lienzo;
	public Lienzo() {
		// TODO Auto-generated constructor stub
		lienzo = new int[filas][columnas];
		for (int i=0;i<filas;i++) {
			lienzo[i][0] = 0;
			lienzo[i][columnas-1] = 0;
		}
		for (int j=0;j<columnas;j++) {
			lienzo[0][j] = 0;
			lienzo[filas-1][j] = 0;
		}
		for (int i = 1; i < filas-1; i++)
			for (int j = 1; j < columnas-1; j++)
				 lienzo[i][j] = 3;
	}
	/**
	 * Muestra el lienzo en pantalla segun los valores de la matriz
	 */
	public void mostrarLienzo(String color) {
		
		for (int i = 0; i < filas; i++) {
			for (int j = 0; j < columnas; j++) {
				if  (lienzo[i][j]==0)System.out.print("- ");
				else if (lienzo[i][j]==1)System.out.print(color+" ");
				else System.out.print("  ");
			}
	System.out.println();
		}
	}
	
	public void insertarCuadrilatero(Punto inicio, Punto fin) {
          
		/*
		 * Se inserta  un cuadrilatero tomando dos puntos de referencia, el de la esquina Noroeste que se ha  introudcio para  la figura 
		 * y el de la esquina sureste que se calcula con las dimensiones
		 *
		 */
			
				for (int i = inicio.getX(); i <= fin.getY(); i++)
					for (int j = inicio.getY(); j <= fin.getX(); j++){				
						
							lienzo[i][j] = 1;//Es un punto del cuadrilatero
			}
			
        }
	


}
