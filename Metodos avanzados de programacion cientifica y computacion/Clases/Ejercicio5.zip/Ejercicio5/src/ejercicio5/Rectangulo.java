package ejercicio5;

public class Rectangulo extends Cuadrilatero {
	private int ancho;
	private int alto;

	public Rectangulo(String color, int x, int y, int numlados, int _ancho,int  _alto) {
		super(color, x, y, numlados);
		// TODO Auto-generated constructor stub
		ancho=_ancho;
		alto=_alto;
	}

	

	@Override
	public void dibujar() {
		// TODO Auto-generated method stub
		 lienzo=new Lienzo();
	
		
		Punto verticeSE=new Punto(verticeNO.getX()+ancho,verticeNO.getY()+alto);
		
               
		lienzo.insertarCuadrilatero(verticeNO,verticeSE);
               
		lienzo.mostrarLienzo(this.color);
		System.out.println("Area del rectangulo: "+calcularArea());
		System.out.println("Longitud del rectangulo: "+calcularLongitud());
		
		
		
		

	}

	@Override
	public double calcularArea() {
		// TODO Auto-generated method stub
		return ancho*alto;
	}

	@Override
	public double calcularLongitud() {
		// TODO Auto-generated method stub
		return 2*ancho+2*alto;
	}

}
