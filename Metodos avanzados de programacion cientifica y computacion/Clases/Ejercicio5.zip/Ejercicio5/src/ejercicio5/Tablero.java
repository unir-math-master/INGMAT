package ejercicio5;

public class Tablero {
	private Figura[] figuras;
	private  int numFiguras=0;
	private int numElementos;

	public Tablero(int _numElementos) {
		// TODO Auto-generated constructor stub
		figuras=new Figura[_numElementos];
		numElementos=_numElementos;
	}
	
	public   void insertarFigura(Figura figura){
		if (numFiguras<numElementos) {
			figuras[numFiguras++]=figura;
		}
	}
	public void dibujarFiguras() {
            System.out.println(numFiguras);
		for (int i=0;i<numFiguras;i++) {
			figuras[i].dibujar();
		}
	}
	
	public void calcularAreas() {
        System.out.println(numFiguras);
	for (int i=0;i<numFiguras;i++) {
		System.out.println("El area de la figura i es:"+figuras[i].calcularArea());
	}
	}
	
	
	public void calcularLongitudes() {
        System.out.println(numFiguras);
	for (int i=0;i<numFiguras;i++) {
		System.out.println("El area de la figura i es:"+figuras[i].calcularLongitud());
	}
	}
	
	public void cambiarColor(int posicionFigura,String color) {
		figuras[posicionFigura].setColor(color);
	}

}
