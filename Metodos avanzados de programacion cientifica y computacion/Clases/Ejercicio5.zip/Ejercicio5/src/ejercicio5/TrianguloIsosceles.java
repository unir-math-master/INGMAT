package ejercicio5;

public class TrianguloIsosceles extends Triangulo {
	double base;
	double lado;

	public TrianguloIsosceles(String color, byte x, byte y, int numlados, double _base, double _lado) {
		super(color, x, y, numlados);
		base=_base;
		lado=_lado;
		// TODO Auto-generated constructor stub
	}

	@Override
	public void dibujar() {
		// TODO Auto-generated method stub

	}

	@Override
	public double calcularArea() {
		
		double altura=Math.sqrt(Math.pow(lado, 2)-Math.pow(base/2,2));
		return base*altura/2;
	}

	@Override
	public double calcularLongitud(){
		// TODO Auto-generated method stub
		return 2*lado+base;
	}

}
