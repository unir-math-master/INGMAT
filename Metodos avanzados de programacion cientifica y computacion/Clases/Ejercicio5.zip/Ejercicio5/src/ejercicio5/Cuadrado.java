package ejercicio5;

public class Cuadrado extends Cuadrilatero {
	
	private int lado;
	
	
	
	public Cuadrado(String color, int x, int y, int numlados,int _lado) {
		super(color, x, y, numlados);
		// TODO Auto-generated constructor stub
		lado=_lado;
	}

	@Override
	public void dibujar() {
		lienzo=new Lienzo();
		Punto verticeSE=new Punto(verticeNO.getX()+lado,verticeNO.getY()+lado);
		lienzo.insertarCuadrilatero(verticeNO,verticeSE);
		lienzo.mostrarLienzo(this.color);
		
		System.out.println("Area del cuadrado: "+calcularArea());
		System.out.println("Longitud del cuadrado: "+calcularLongitud());

	}

	@Override
	public double calcularArea() {
		// TODO Auto-generated method stub
		return Math.pow(lado,2);
	}

	@Override
	public double calcularLongitud() {
		// TODO Auto-generated method stub
		return 4*lado;
	}

}
