/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio5;

/**
 *
 * @author mluisadiez
 */
public abstract class FiguraCurva  extends Figura {
    Punto _centro;
    FiguraCurva(String  color, int x, int y){
        super(color);
        _centro=new Punto(x,y);
    }
}
