/*********************************************************
 *     Clase que permite crear los fil�sofos que         *
 * participan en la tertulia.                            *
 *********************************************************/
 
 
 import java.util.*;
 
 public class Filosofo extends Thread {
   
    private Random random = new Random();
   
    private int id;
   
    private Palillo izdo, dcho;
   
/**
 *  //metodo para coger palillos y liberar si no se consigue
 * @return 
 */
    
    private  boolean cogerPalillos(){
        try{
            dcho.cogerPalillo(id);
            Filosofo.sleep(random.nextInt(1000) + 100);
            if (!izdo.cogerPalillo(id)){
                dcho.soltarPalillo(id);
                return false;
            }
            return  true;
        }catch (InterruptedException ex) {
            return false;
        }
      }
        
  
    /** 
     * 
     *
     */
    public Filosofo(int id, Palillo dcho, Palillo izdo){
        // Se asignan los valores recibidos a las variables
        this.id = id;
        this.dcho = dcho;
        this.izdo = izdo;
        
        
    }
    
    /**
     * Método que se ejecuta indefinidamente
     */
    @Override
    public void run(){
        while(true){ // Se repite infinitamente While
            
            try { // try / catch
                
                //intenta coger los dos palillos pero si no lo consigue libera el que tiene  y espera en la mesa  
                while (!cogerPalillos()){
                    System.out.println("El Filósofo " + (id+1) +" está esperando para comer");
                     Filosofo.sleep(random.nextInt(1000) + 100);
                };
                
                    // Si se han conseguido los dos palillos come
                    
                        
                    System.out.println("El Filósofo " + (id+1) + " está comiendo.");
                    
                    
                    try {
                        sleep(random.nextInt(1000) + 500);
                    } catch (InterruptedException ex) {
                        System.out.println("Error. " + ex.toString());
                      } 
                        
                
                izdo.soltarPalillo(id);
                   
                dcho.soltarPalillo(id);
                
                
                    
              //  El filoso piensa
                 System.out.println("El Filósofo " + (id+1) + " está pensando.");
                try {
                    Filosofo.sleep(random.nextInt(1000) + 100);
                } catch (InterruptedException ex) {
                    System.out.println("Se ha  producido una interruupción" + ex.toString());
                 }
               } catch (InterruptedException ex) {
                ex.printStackTrace();
                System.err.println("\"La cena ha terminado");
               
            } // Fin del try / catch
            
        
            
        }  // Fin de Se repite infinitamente While

        
    }
}