/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mluisadiez
 */
import java.util.*;
public class Palillo {
    private Random random = new Random();
      private int id;
     private boolean libre = true;
    
    /**
     * Constructor del Monitor clase Palillo
     * 
     * 
     */
    public Palillo(int id){
        this.id = id;
    }
    
   
    /**
     * 
     */
    public synchronized boolean cogerPalillo(int id_f) throws InterruptedException{
        if (!libre) 
            return false;
        System.out.println("El Filósofo " + (id_f+1) + " coge el palillo " + (id+1));
        
        libre = false;
        return true;
    }
 
    
    /**
     
     */
    public synchronized void soltarPalillo(int id_f) throws InterruptedException {
        libre = true;
        System.out.println("El Filósofo " + (id_f+1) + " suelta el  palillo " + (id+1));
        // Siempre se valora si el log es distinto a null, si lo es se ecribe en la interface gráfica:
         this.notify();
    }
}
