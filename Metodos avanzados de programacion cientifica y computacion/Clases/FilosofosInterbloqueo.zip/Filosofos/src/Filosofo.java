/*********************************************************
 *     Clase que permite crear los fil�sofos que         *
 * participan en la tertulia.                            *
 *********************************************************/
 
 
 import java.util.*;
 
 public class Filosofo extends Thread {
   
    private Random random = new Random();
   
    private int id;
   
    private Palillo izda, dcha;
   

    
    /** 
     *
     * 
     */
    public Filosofo(int id, Palillo dcha, Palillo izqda){
        // Se asignan los valores recibidos a las variables
        this.id = id;
        this.dcha = dcha;
        this.izda = izqda;
     
        
    }
    
    /**
     * Método que se ejecuta indefinidamente,
     */
    @Override
    public void run(){
        while(true){ // Se repite infinitamente 
            
            try { 
                
            
                   
            
                dcha.cogerPalillo(id);
                //simula el tiempo que puede tardar en  coger el otro palillo
                Filosofo.sleep(random.nextInt(1000) + 100);
                 
                izda.cogerPalillo(id);
                    
                
                 // Si ha conseguido el Tenedor Izquierdo  el filósofo come
                    
                         
                System.out.println("El Filósofo " + (id+1) + " está comiendo.");
                    
                    
                try {
                        sleep(random.nextInt(1000) + 500);
                 } catch (InterruptedException ex) {
                        System.out.println("Error. " + ex.toString());
                 } 
                        
                
                izda.soltarPalillo(id);
                   
                dcha.soltarPalillo(id);
                

                 System.out.println("El Filósofo " + (id+1) + " está pensando.");
                try {
                    Filosofo.sleep(random.nextInt(1000) + 100);
                } catch (InterruptedException ex) {
                    System.out.println("Se ha producido una interrupción" + ex.toString());
                 }
               } catch (InterruptedException ex) {
                ex.printStackTrace();
                System.err.println("Se ha producido una interrupción  " + ex.toString());
               
            } // Fin del try / catch
            
          
            
        }  // Fin de Se repite infinitamente While


       
    }
}