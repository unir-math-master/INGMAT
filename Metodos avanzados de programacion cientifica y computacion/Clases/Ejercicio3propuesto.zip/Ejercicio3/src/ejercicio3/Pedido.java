package ejercicio3;

import java.util.ArrayList;


public class Pedido {
    //el numero de pedido nunca cambia
	final private  int numPedido;

    private Cliente cliente;
    private Direccion direccionEnvio=null;
    
  
   /**
   * 
   * @element-type LineaPedido
   */
    private ArrayList<LineaPedido>  listaProductos;
    
  public Pedido(Cliente _cliente, int _numPedido){
      numPedido=_numPedido;
      cliente=_cliente;
      listaProductos=new ArrayList<LineaPedido>();
      
  } 
  /**
   * comprueba si hay un producto en el pedido
   * @param idProducto
   * @return
   */
  private boolean contieneProducto(int idProducto){
      for (int i=0; i<listaProductos.size();i++){
          LineaPedido ltemp=listaProductos.get(i);
          
          if (ltemp.getProducto()==idProducto)return true;
      }
      return false;
  }
  
  /**
   * Obtiene  la liena de pedido de un producto, es decir, su cantidad y producto
   * es privada porque solo se usa internamente
   * @param idProducto
   * @return
   */
  private LineaPedido getLinea(int idProducto){
      for (int i=0; i<listaProductos.size();i++){
          LineaPedido ltemp=listaProductos.get(i);
         
          if (ltemp.getProducto()==idProducto)return ltemp;
      }
      return  null;
  }
  
  
  public int getNumPedido(){
      return this.numPedido;
  }
  
  /**
   * 
   * @param producto
   * @param cantidad
   * @throws YaEstaEnPedido
   */
  public void insertarProducto(Producto producto, int cantidad) {
      //se inserta en  la lista de  productos una linea de pedido con el producto y la cantidad
  try{
    	  int idProducto=producto.getId();
      
      if (contieneProducto(idProducto)){
          if (producto instanceof ProductoVirtual){ throw new  YaEstaEnPedido();}
          else{
          getLinea(idProducto).incrementarCantidad(cantidad);
          }
      }else {
          LineaPedido nueva=new LineaPedido(idProducto,cantidad);
          listaProductos.add(nueva);
      }   
  }catch (YaEstaEnPedido e) {System.out.println(e.mensaje);}
  }
  
  /**
   * 
   * @param calle
   * @param numero
   * @param codigopostal
   * @param poblacion
   * @param pais
   */

  public void aniadirDirEnvio(String calle, String numero, String codigopostal, String poblacion, String pais) {
      //se añade la dirección de envío
      direccionEnvio=new Direccion(calle,numero,codigopostal,poblacion,pais);
  }
  
  /**
   * visualiza los datos   del pedido
   */
  public void visualizar(){
	
      System.out.printf("%-30s", "Número pedido");
      System.out.printf("%-20d%n", numPedido);
      System.out.printf("%-20s%n", "Cliente");
      cliente.visualizar();
      System.out.println();
      if (direccionEnvio!=null)
       direccionEnvio.visualizar();
      for (int  i=0;i<listaProductos.size();i++){
          LineaPedido lp=listaProductos.get(i);
          lp.visualizar();
          
      }
  }

 
}