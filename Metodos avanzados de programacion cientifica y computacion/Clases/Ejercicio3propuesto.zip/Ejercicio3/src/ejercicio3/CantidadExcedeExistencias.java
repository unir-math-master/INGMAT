/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3;

/**
 *
 * Clase de tipo excepcion para controlarsis se quiere comprar más de las existencias
 */

public class CantidadExcedeExistencias extends Exception{
    int _existencias;
    String mensaje="La cantidad es mayor  que las existencias";
    public CantidadExcedeExistencias(int  existencias){
        _existencias=existencias;
        
        
    }
}
