package ejercicio3;



abstract public class Producto {
	   protected int id;

	    
	    public Producto(int i){
	       id=i;
	    }
	    public int getId(){
	        return id;
	    }
	    public void setId(int _id){
	        id=_id;
	    }
	    abstract public void comprar(Pedido pedido, int cantidad)  ;
	    abstract public void visualizar();
    
}