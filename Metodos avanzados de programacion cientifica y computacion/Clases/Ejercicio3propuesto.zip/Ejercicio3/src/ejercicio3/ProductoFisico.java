package ejercicio3;

import java.util.Scanner;




public class ProductoFisico extends Producto {
	//el peso y las  dimensiones no cambian, si cambian  es otro producto
	  final private float peso;

	  final private ConjuntoDimensiones dimensiones;
	  
	  private float costeTransporte;
	  int stock;
  
    /**
	   * 
	   * @param _id
	   * @param _peso
	   * @param _alto
	   * @param _ancho
	   * @param _largo
	   * @param _costeTransporte
	   */
	  
	 public ProductoFisico(int _id,float _peso, float _alto, float _ancho, float _largo, float _costeTransporte, int _stock){
	      //se invoca al constructor de la clase base
		  super(_id);
	      peso=_peso;
	      //relacion  de composicion
	      dimensiones=new ConjuntoDimensiones(_alto,_ancho,_largo);
	      costeTransporte=_costeTransporte;
	      stock=_stock;
	      
	 }
	 public void setCosteTransporte(float _costeTransporte) {
		  costeTransporte=_costeTransporte;
	  }
	  
	  
	  /**
	   * 
	   * devuelve el valor del atributo
	   * 
	   * @return  el peso
	   */
	  public float getPeso() {
		  return peso;
	  }
	  
	  /**
	   * 
	   * devuelve el valor del atributo
	   * 
	   * @return  el coste de transporte
	   */
	  public float getCosteTransporte() {
		  return costeTransporte;
	  } 
	  
	  /**
	   * 
	   * devuelve el valor de un atributo compuesto
	   * 
	   * @return el conjunto de las dimensiones
	   */
	  public ConjuntoDimensiones getDimensiones() {
		  return dimensiones;
	  }
	  
    
	  @Override
	  public void comprar(Pedido pedido, int cantidad) {
      //invoca a insertarProducto del pedido
	  
	   try{
	        if (cantidad<stock){
	        	pedido.insertarProducto(this, cantidad);
	        	quitarStock(cantidad);
	        }else throw new CantidadExcedeExistencias(stock);
		   }catch(CantidadExcedeExistencias e){
	       Scanner flujoEntrada=new Scanner(System.in);
	       System.out.println("No hay tantas existencias");
	       System.out.println("Inserte una cantidad menor o igual a "+e._existencias);
	       cantidad=flujoEntrada.nextInt();
	       comprar(pedido, cantidad);
		   }
	  }
     
    

	  public void aniadirStock(int cantidad) {
		  stock+=cantidad;
	  }

	  public void quitarStock(int cantidad) {
	      stock-=cantidad;
	  }
      
	  @Override
	  public void visualizar(){
		  
	      System.out.printf("%-30s", "Identificador producto");
	      System.out.printf("%-10s", "Peso");
	      System.out.printf("%-10s", "Alto");
	      System.out.printf("%-10s", "Ancho");
	      System.out.printf("%-10s", "Largo");
	      System.out.printf("%-20s", "Coste Transporte");
	      System.out.printf("%-10s", "Stock");
	      System.out.println();
	      System.out.printf("%-30d", id);
	      System.out.printf("%-10.2f", peso);
	      System.out.printf("%-10.2f", dimensiones.alto);
	      System.out.printf("%-10.2f", dimensiones.ancho);
	      System.out.printf("%-10.2f", dimensiones.largo);
	      System.out.printf("%-20.2f",costeTransporte);
	      System.out.printf("%-10d", stock);
	  }
	    
}