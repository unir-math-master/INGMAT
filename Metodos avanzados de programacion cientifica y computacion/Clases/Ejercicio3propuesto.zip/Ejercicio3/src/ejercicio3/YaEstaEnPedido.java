/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3;

/**
 *
 * @author mluisadiez
 */
public class YaEstaEnPedido extends Exception{
   String mensaje="Ya ha compado este producto virtual, no puede comprar más unidades";
}
