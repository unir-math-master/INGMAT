package ejercicio3;
public class Direccion {
	  public String calle;

	  public String numero;

	  public String codigoPostal;

	  public String poblacion;

	  public String pais;

	 public Direccion(String _calle,String _numero,String _codigoPostal, String _poblacion, String _pais){
	     calle=_calle;
	     numero=_numero;
	     codigoPostal=_codigoPostal;
	     poblacion=_poblacion;
	     pais=_pais;
	 }
	 public void visualizar(){
		 System.out.printf("%-30s", "Calle y numero");
		 System.out.printf("%-10s%n",calle+", "+numero);
     
		 System.out.printf("%-30s", "Codigo Postal y  Poblacion");
		 System.out.printf("%-100s%n", codigoPostal+" "+poblacion);
		 System.out.printf("%-30s", "Pais");
		 System.out.printf("%-30s%n",pais);
 }
}