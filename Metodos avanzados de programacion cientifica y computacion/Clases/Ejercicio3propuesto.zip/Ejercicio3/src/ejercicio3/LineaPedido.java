package ejercicio3;

public class LineaPedido {

	  private int cantidad;

    
	  private int producto;
	  
	  public LineaPedido(int _id,int _cantidad){
	      cantidad=_cantidad;     
	      producto=_id;
	      
	  }
	  public int getProducto(){
	      return producto;
	  }
	  public int getCantidad(){
	      return cantidad;
	  }
	  public void incrementarCantidad(int incremento){
	      cantidad+=incremento;
	    
	  }
	  public void decrementarCantidad(int incremento){
	      cantidad-=incremento;
	    
	  }
	  
	  public void visualizar() {
		  System.out.printf("%-30s", "Identificador producto");
	      System.out.printf("%-10s", producto);
	       System.out.printf("%-30s", "Cantidad");
	       System.out.printf("%-100s%n", cantidad);
	  
	  }
}