package ejercicio3;

import java.util.HashMap;

public class Almacen {

	private int numProductos=0;
	
	private HashMap<Integer,Producto>  listaProductos;
	
	public Almacen() {
		// TODO Auto-generated constructor stub
		listaProductos=new HashMap<Integer,Producto> ();
	}
	public int getNumProductos(){
	     return listaProductos.size();
	 }

	 public Producto getProducto(int idProducto){
	     //es importante indicar que el HasMap no puede usar el tipo int primitivo, sino un tipo Intger, objeto totalmente compatible con int
		 //por eso hay  que hacer el uso de Integer.valueOf que obtiene  el objeto Integer con el valor del int
	     Producto pr=listaProductos.get(Integer.valueOf(idProducto));
	  
	     return pr;
	 }
	 
	 public void aniadirStockProducto(int idProducto, int cantidad) {
	      // llama a una fncion  de producto que  añada stock
	      if (listaProductos.containsKey(idProducto)){
	          Producto pr=listaProductos.get(idProducto);
	          if (pr instanceof ProductoFisico)((ProductoFisico)listaProductos.get(idProducto)).aniadirStock(cantidad);
	          else System.out.println("Los productos virtuales no tienen stock");
	      }
	     
	  }
	 
	//quita  stock a un nproducto tras una compra
	  public void quitarStockProducto(int idProducto, int cantidad) {
	      if (listaProductos.containsKey(idProducto)){
	          Producto pr=listaProductos.get(idProducto);
	          if (pr instanceof ProductoFisico)((ProductoFisico)listaProductos.get(idProducto)).quitarStock(cantidad);
	          else System.out.println("Los productos virtuales no tienen stock");
	      }
	  }
	  
	  public void insertarProducto(Producto producto){
		  int idProducto=numProductos;
	      producto.setId(idProducto);
	      listaProductos.put(idProducto, producto);
	      numProductos++;
	      
	  }
	  
	  public void listarProductos(){
	      //recorre los valores del HashMap
	      for (Object value :listaProductos.values()) {
	       ((Producto)value).visualizar();
	       System.out.println();
	       }
	  }
}
