package ejercicio3;

import java.util.*;


public class Cliente {

	 private String idCliente;

	  private String nombre;

	  private String apellidos;

	  private String dni;

	  private String email;

	  private String clave;
	  //se  guarda  el pedido activo del cliente
	  private Pedido pedidoActivo=null;

	    /**
	   * 
	   * @element-type Pedido
	   */
	    private  ArrayList<Pedido> listaPedidos;
	    private Direccion direccion;
	    public Cliente(String _idCliente, String _nombre,String _apellidos,String _dni,String _email,String _clave,String _calle,String _numero,String _codigoPostal, String _poblacion, String _pais){
	        idCliente=_idCliente;
	        nombre=_nombre;
	        apellidos=_apellidos;
	        dni=_dni;
	        email=_email;
	        clave=_clave;
	        listaPedidos=new ArrayList<Pedido>();
	        direccion=new Direccion(_calle,_numero,_codigoPostal,_poblacion,_pais);
	    }
	   //se pone como activo el pedido que  se acaba de crear
    public void aniadirPedido(Pedido pedido){
        listaPedidos.add( pedido);
        pedidoActivo=pedido;
        
    }
    
    public Pedido getPedidoActivo(){
        return pedidoActivo;
    }
    
    public String getIdCliente(){
        return idCliente;
    }
    
    public void finalizarPedido(){
        pedidoActivo=null;
    }
    
    public void visualizar(){
       System.out.printf("%-30s", "Identificador cliente");
       System.out.printf("%-10s%n", idCliente);
       System.out.printf("%-30s", "Nombre y apellidos");
       System.out.printf("%-100s%n", nombre+" "+apellidos);
      System.out.printf("%-30s", "dni");
      System.out.printf("%-10s%n", dni);
      System.out.printf("%-30s", "email");
      System.out.printf("%-50s%n", email);
      System.out.printf("%-30s", "clave");
      System.out.printf("%-50s%n", clave);
      System.out.printf("%-100s%n", "Dirección facturación");
      direccion.visualizar();
      
    }
    
}