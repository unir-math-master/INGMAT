package ejercicio3;

import java.util.ArrayList;
import java.util.HashMap;

public class Empresa {

//se usan para construir los identificadores de Producto y de Cliente
//nunca se decrementa
   
   private int numClientes=0;
   /**
   * 
   * @element-type Producto
   */
  //se construye un HashMap indexado por enteros, de esta forma se evita el problema de indexar por la posición en el array o ArrayList
 
  private Almacen almacen;
    /**
   * 
   * @element-type Cliente
   */
  //los clientes se indexan por un identificador String, para mostrar el uso del HashMap
  private HashMap<String,Cliente> listaClientes;
    /**
   * 
   * @element-type Pedido
   */
  //como los pedidos no se elminan  (se  deja  siempre constancia aunque se hayan anulado), se indexan por el orden en el ArrayList
  private ArrayList<Pedido>  listaPedidos;
  
 public Empresa(){
     almacen=new Almacen();
     listaClientes=new HashMap<String,Cliente>();
     listaPedidos=new ArrayList<Pedido>();
 }
 
  
  public Cliente getCliente(String idCliente){
     return listaClientes.get(idCliente);
 }
  
  public Almacen getAlmacen() {
	  return almacen;
  }
  
  /**
   * encripta la clave facilitada  por el cliente
   * @param email
   * @param clave
   * @param hashType
   * @return
   */
 private String encriptarClave(String email, String clave, String hashType){
     try {
            java.security.MessageDigest md = java.security.MessageDigest.getInstance(hashType);
            String txt=email+clave;
            byte[] array = md.digest(txt.getBytes());
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < array.length; ++i) {
                sb.append(Integer.toHexString((array[i] & 0xFF) | 0x100)
                        .substring(1, 3));
            }
            return sb.toString();
        } catch (java.security.NoSuchAlgorithmException e) {
            System.out.println(e.getMessage());
        }
        return null;
 }
 

 public String registrarCliente(String email, String clave, String nombre, String apellidos, String dni, String calle, String numero, String codigopostal, String poblacion, String pais) {
     //construye  un identificador para el cliente
     String idCliente="cl"+numClientes;
     numClientes++;
     //se supone que la clave se encriptará
     String claveEncriptada=encriptarClave(email,clave,"SHA1");
     
     //crea el cliente  y lo inserta
     Cliente nuevoCliente=new Cliente(idCliente,nombre,apellidos,dni,email,claveEncriptada,calle,numero,codigopostal,poblacion,pais);
     listaClientes.put(idCliente, nuevoCliente);
      return idCliente;
  
  }

 /**
  * se supone que cuando un cliente se conecta tiene  una bolsa "pedido" vacia, activa
  * @param idCliente
  * @return
  */
  public int iniciarPedido(String idCliente) {
      Cliente cliente=listaClientes.get(idCliente);
      //se crea el Pedido y se asocia al cliente
      int idPedido=listaPedidos.size();
      Pedido pedido=new Pedido(cliente,idPedido);
      listaPedidos.add(pedido);
      cliente.aniadirPedido(pedido);
  return idPedido;
  //devuelve el numero de pedido

  }

  public void listarPedidos(){
	  //recorre los pedidos
      for (int i=0;i<listaPedidos.size();i++) {
       Pedido pedido=listaPedidos.get(i);
       pedido.visualizar();
       System.out.println("----------------------------------------------");
       }
  }
   public void listarClientes(){
	   //recorre los valores del HashMap
      for (Object value :listaClientes.values()) {
       ((Cliente)value).visualizar();
       System.out.println("----------------------------------------------");
       }
  }
}