package ejercicio3;
public class ProductoVirtual extends Producto {

  private String version;
  
    public ProductoVirtual(int _id, String _version){
     super(_id);
     version=_version;
    }
    @Override
    public void comprar(Pedido pedido, int cantidad) {
      //comprueba que la cantidad sea 1
      //invoca a insertarProducto del pedido
      if (cantidad>1){ System.out.println("La cantidad máxima de este producto es 1. Se asignará solo 1");}
      pedido.insertarProducto(this, 1);
      
    }
    /**
	   * 
	   * funcion  que cambia el valor del atributo
	   * 
	   * @param _version
	   */
	  public void setVersion(String _version) {
		 version=_version;
	  }
	  
	  /**
	   *  
	   * función que  devuelve  el valor del atributo
	   * @return la version 
	   */
	  public String getVersion() {
			 return version;
		  }
    @Override
	  public void visualizar(){
      System.out.printf("%-30s", "Identificador producto");
      System.out.printf("%-30s", "Version");
      
      System.out.println();
      System.out.printf("%-30d", id);
      System.out.printf("%-30s", version);
   
  }
    
}