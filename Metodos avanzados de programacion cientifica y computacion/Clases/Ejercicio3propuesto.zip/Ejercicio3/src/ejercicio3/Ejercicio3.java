/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3;
import java.util.*;
import java.io.*;
/**
 *
 * @author mluisadiez
 */
public class Ejercicio3 {
    static Empresa miEmpresa;
    static Almacen almacen;
    static Scanner flujoEntrada=new Scanner(System.in);
    static String clienteActivo;
    static FileWriter output; 



    public static Producto insertarProducto(){
        String entrada;
        
        Producto tempProducto=null;
        int opcion;
      
        System.out.println("Para insertar un producto, teclee:\n 1-Producto Físico \n 2-Producto virtual");
        opcion=flujoEntrada.nextInt();
        if (opcion==1){
            System.out.println("Inserte peso del producto");
            float peso=flujoEntrada.nextFloat();
            System.out.println("Inserte alto del producto");
            float alto=flujoEntrada.nextFloat();
            System.out.println("Inserte ancho del producto");
            float ancho=flujoEntrada.nextFloat();
            System.out.println("Inserte largo del producto");
            float largo=flujoEntrada.nextFloat();
            System.out.println("Inserte coste transporte del producto");
            float ctransporte=flujoEntrada.nextFloat();
            System.out.println("Inserte stock del producto");
            int stock=flujoEntrada.nextInt();
            tempProducto=new ProductoFisico(0,peso,alto,ancho,largo,ctransporte,stock);
        }else{
            System.out.println("Inserte versión del producto");
            String version=flujoEntrada.next();
            tempProducto=new ProductoVirtual(0,version);
        }
        return tempProducto;
    }
    
    public static void registrarCliente(){
        System.out.println("Para registrarse introduzca los datos que se le piden a continuación");
        flujoEntrada.nextLine();
        System.out.println("Inserte nombre");
            String nombre=flujoEntrada.nextLine();
 
        System.out.println("Inserte apellidos");
            String apellidos=flujoEntrada.nextLine();
            
        System.out.println("Inserte dni");
            String dni=flujoEntrada.next();
            flujoEntrada.nextLine();
        System.out.println("Inserte calle");
            String calle=flujoEntrada.nextLine();
            
        System.out.println("Inserte numero");
            String numero=flujoEntrada.next();
            flujoEntrada.nextLine();
        System.out.println("Inserte codigo postal");
            String codigoPostal=flujoEntrada.next();
            flujoEntrada.nextLine();
        System.out.println("Inserte población");
            String poblacion=flujoEntrada.nextLine();
        System.out.println("Inserte pais");
            String pais=flujoEntrada.nextLine();
        System.out.println("Inserte email");
            String email=flujoEntrada.next();
        System.out.println("Inserte clave");
            String clave=flujoEntrada.next();
       
        clienteActivo=miEmpresa.registrarCliente(email, clave, nombre, apellidos, dni, calle, numero, codigoPostal, poblacion, pais);
        
            
    }
    
    public static void hacerPedido(){
        miEmpresa.iniciarPedido(clienteActivo);
        
    }
    
    public static void comprar(){
        Producto productoSeleccionado=null;
        int idProducto;
        try{
            System.out.println("Indique  el identificador del producto que quiere comprar");
        
          idProducto=flujoEntrada.nextInt();
          productoSeleccionado=almacen.getProducto(idProducto);
           if (productoSeleccionado==null)
            throw new ProductoInexistente();
        
           
        System.out.println("Inserte cantidad que quiere comprar");
            int cantidad=flujoEntrada.nextInt();
         
         
         Cliente cliente=miEmpresa.getCliente(clienteActivo);
       
         Pedido pedidoActivo=cliente.getPedidoActivo();
         
         productoSeleccionado.comprar(pedidoActivo, cantidad);
         }catch(ProductoInexistente e){
               System.out.println(e.mensaje);
               comprar();
           }
         
         }
    
    public static boolean seguirInsertandoProducto(){
         System.out.println("¿Quiere insertar otro producto?  S/N");
            String si=flujoEntrada.next();
            if (si.equals("S")||si.equals("s")) return true;
            else return false;
    }
    
    public static boolean seguirComprando(){
         System.out.println("¿Quiere comprar otro producto?  S/N");
            String si=flujoEntrada.next();
            if (si.equals("S")||si.equals("s")) return true;
            else return false;
    }
    
    public static void aniadirStock(int idProducto, int cantidad){
        ((ProductoFisico)almacen.getProducto(idProducto)).aniadirStock(cantidad);
    }
    
    
   
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException{
        // TODO code application logic 
       miEmpresa=new Empresa();
       almacen=miEmpresa.getAlmacen();
      
        
        do{
            Producto producto=insertarProducto();
            almacen.insertarProducto(producto);
            System.out.println("Producto añadido.\nTiene "+almacen.getNumProductos()+" productos");
        }while (seguirInsertandoProducto());
       
        System.out.println("***************************************************************************");
        System.out.println("***************************************************************************");
        System.out.println();
        System.out.println();
        registrarCliente();
        miEmpresa.listarClientes();
        System.out.println("***************************************************************************");
        System.out.println("***************************************************************************");
        System.out.println("***************************************************************************");
        System.out.println();
        System.out.println();
        hacerPedido();
        System.out.println("***************************************************************************");
        System.out.println("Los productos disponibles son:");
         almacen.listarProductos();
         System.out.println("***************************************************************************");
        System.out.println();
        do{
            comprar();
            
       
        }while(seguirComprando());
        System.out.println("***************************************************************************");
        System.out.println("***************************************************************************");
        System.out.println("***************************************************************************");
        System.out.println();
        System.out.println();
        System.out.println("Este es el resumen de su pedido");
        miEmpresa.listarPedidos();

        //prueba de añadir stock
        System.out.println("Indique el número  de producto  al que quiere añadir stock.");
    	 
    	 int numP=flujoEntrada.nextInt();
    	  System.out.println("Indique la cantidad que  quiere añadir.");
	    	 
	    	 int cantidad=flujoEntrada.nextInt();
	    	 almacen.aniadirStockProducto(numP, cantidad);
        
	    	 System.out.println("Los productos disponibles son:");
	    	 almacen.listarProductos();
        
	    	 System.out.println("***************************************************************************");
	         System.out.println("***************************************************************************");
	         System.out.println();
	         System.out.println();
	         System.out.println("Este es el resumen de su pedido");
         miEmpresa.listarPedidos();
         
        System.exit(0);
        
        
        
    }
    
}
