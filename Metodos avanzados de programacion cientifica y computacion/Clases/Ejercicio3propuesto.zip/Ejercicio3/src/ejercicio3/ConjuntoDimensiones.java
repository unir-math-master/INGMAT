/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3;

/**
 *
 * @author mluisadiez
 */
public class ConjuntoDimensiones {
    public float alto;
    public float ancho;
    public float largo; 
public ConjuntoDimensiones(float _alto, float _ancho,float _largo){
    alto=_alto;
    ancho=_ancho;
    largo=_largo;
}
}