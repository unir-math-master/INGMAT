/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

/**
 *
 * @author mluisadiez
 */


public abstract class Vehiculo {
    Color color;
    int identificador;
    float potencia;
    public Vehiculo(Color _color,int _identificador, float _potencia){
        color=_color;
        identificador=_identificador;
        potencia=_potencia;
    }
    public abstract float calcularConsumo();
    public abstract void  mostrarCaracteristicas();
    
}
