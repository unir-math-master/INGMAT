/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

/**
 *
 * @author mluisadiez
 */
public class Moto extends Vehiculo{
    
    public Moto(int  identificador,Color color,float potencia){
        super(color,identificador,potencia);
        
    }
    @Override
    public float calcularConsumo(){
        return potencia*2*(float)0.12;
    }
    @Override
    public void mostrarCaracteristicas(){
      System.out.printf("%-10s", "MOTO:");
      System.out.printf("%-10d%n", identificador+1); 
      System.out.println("--------------------------------------------------");
      System.out.printf("%-10s", "Color:");
      System.out.printf("%-10s%n", color);
      System.out.printf("%-10s", "Potencia:");
      System.out.printf("%-10.2f%n", potencia);
      System.out.printf("%-10s", "Consumo:");
      System.out.printf("%-10.2f%n", calcularConsumo());
        
       System.out.println("XXXX           ");
       System.out.println("  XX           ");
       System.out.println("  XX           ");
       System.out.println("  XX           ");
       System.out.println("  XX      XXXXXXX");
       System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXX");
       System.out.println("XXXXXXX        XXXXXXX");
       System.out.println(" XXX   X      X   XXX   ");
       System.out.println("XXXXX   X    X   XXXXX    ");
       System.out.println("XXXXX    X  X    XXXXX        ");
       System.out.println(" XXX     X  X     XXX  ");
       System.out.println( );
       System.out.println( );
       System.out.println("==================================================");
    }
    
}
