/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;

/**
 *
 * @author mluisadiez
 */
public class Coche extends Vehiculo{
    
    public Coche(int  identificador,Color color,float potencia){
        super(color,identificador, potencia);
    }
    @Override
    public float calcularConsumo(){
        return potencia*4*(float)0.12;
    }
    @Override
     public void mostrarCaracteristicas(){
      System.out.printf("%-10s", "COCHE:");
      System.out.printf("%-10d%n", identificador+1); 
      System.out.println("--------------------------------------------------");
      System.out.printf("%-10s", "Color:");
      System.out.printf("%-10s%n", color);
      System.out.printf("%-10s", "Potencia:");
      System.out.printf("%-10.2f%n", potencia);
      System.out.printf("%-10s", "Consumo:");
      System.out.printf("%-10.2f%n", calcularConsumo());
        
       System.out.println("          XXXXXXXXXXXXXXXXXXXXXXXXXXXXXX           ");
       System.out.println("         X           XX                X");
       System.out.println("        X             XX               X");
       System.out.println("       X             XX                X");
       System.out.println("      X             XX                 X");
       System.out.println("  XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
       System.out.println("  XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
       System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
       System.out.println("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
       System.out.println(" XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX");
       System.out.println("XXXXXXXX                            XXXXXXXX");
       System.out.println("  XXXX  X                          X  XXXX   ");
       System.out.println(" XXXXXX  X                        X  XXXXXX    ");
       System.out.println(" XXXXXX   X                      X   XXXXXX        ");
       System.out.println("  XXXX    X                      X    XXXX  ");
       System.out.println( );
       System.out.println( );
       System.out.println("==================================================");
    }
    
}
