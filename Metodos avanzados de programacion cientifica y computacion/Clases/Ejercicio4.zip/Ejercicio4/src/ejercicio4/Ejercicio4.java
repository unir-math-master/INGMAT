/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio4;
import java.io.*;
import java.util.Scanner;
/**
 *
 * @author mluisadiez
 */
public class Ejercicio4 {
     private static Vehiculo[] flota=new Vehiculo[5];
     private static int contadorVehiculos=0;
     static Scanner flujoEntrada=new Scanner(System.in);
    
     public static void insertarVehiculo(int id,int tipoVehiculo,Color color, int potencia){
         if (tipoVehiculo==0){
        	 //para  el polimorfismo se manejan los objetos de cualuiera de los tipos con referencias a la clase base
            flota[contadorVehiculos++]=new Moto(id,color,potencia);
         }
         else
            flota[contadorVehiculos++]=new Coche(id,color,potencia);
         
     }
     public static void configurarVehiculo(int id) throws IOException{
        System.out.println("Indique el vehículo que quiere configurar:  0(moto)/1(Coche)");
        int vehiculo=flujoEntrada.nextInt();
        flujoEntrada.nextLine();
        System.out.println("Indique el color del vehículo:  ROJO, AZUL, VERDE, BLANCO");
        String color=flujoEntrada.next();
        flujoEntrada.nextLine();
        System.out.println("Introduzca la potencia vehículo como numero entero");
        int potencia=flujoEntrada.nextInt();
        insertarVehiculo(id,vehiculo,Color.valueOf(color),potencia);
        flujoEntrada.nextLine();
            
    }
     public static void mostrarFlota(){
    	 //polimorfismo. Ligadura tardía o dinámica
         for (int i=0;i<5;i++) flota[i].mostrarCaracteristicas();
     }
     
    /**
     * @param args the command line arguments
     */
   
    public static void main(String[] args) throws IOException{
   
        System.out.println("Introduzca la flota  de vehiculos");
        for (int i=0;i<5;i++)configurarVehiculo(i);
        System.out.println("La flota  de vehiculos disponibles es:");
        System.out.println("***************************************");
        mostrarFlota();
        
    }
    
}
