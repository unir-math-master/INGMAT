import java.util.Date;

public class Transaccion {

  private int puntos;

  private Date fecha;

    private Servicio generadoPor;
    private TarjetaCliente tarjeta;
    private CuentaFidelizacion cuenta;

  public ProgramaFidelizacion programa() {
  return null;
  }
}