import java.util.Vector;

public class NivelServicio {

  private String nombre;

    private ProgramaFidelizacion myProgramaFidelizacion;
    /**
   * 
   * @element-type Afiliacion
   */
  private Vector  laAfiliacion;
    /**
   * 
   * @element-type Servicio
   */
  private Vector  serviciosDisponibles;
}