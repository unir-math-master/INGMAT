import java.util.Vector;

public class ProgramaSocios {

  private int numSocios;

    /**
   * 
   * @element-type ProgramaFidelizacion
   */
  private Vector  losProgramasFidelizacion;
    /**
   * 
   * @element-type Servicio
   */
  private Vector  serviciosPrestados;
}