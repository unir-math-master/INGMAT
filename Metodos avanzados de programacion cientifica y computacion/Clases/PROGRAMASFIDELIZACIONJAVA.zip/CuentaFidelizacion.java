import java.util.Vector;

public class CuentaFidelizacion {

  private int puntos;

    /**
   * 
   * @element-type Transaccion
   */
  private Vector  transacciones;
  
  public Afiliacion laAfiliacion;

  public void acumularPuntos(int p) {
  }

  public void canjearPuntos(int p) {
  }

  public boolean estaVacia() {
  return false;
  }
}