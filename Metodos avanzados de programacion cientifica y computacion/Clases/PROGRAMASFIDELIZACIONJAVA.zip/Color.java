public enum Color {  Platino, Oro }
