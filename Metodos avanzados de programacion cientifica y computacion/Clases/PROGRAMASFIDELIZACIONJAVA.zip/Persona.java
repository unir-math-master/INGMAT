import java.util.Date;

public class Persona {

  private Date fechaNacimiento;

  private String nombre;
}