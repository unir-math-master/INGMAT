import java.util.Vector;

public class Cliente extends Persona {

  private String idCliente;

    /**
   * 
   * @element-type TarjetaCliente
   */
  private Vector  tarjetas;
    /**
   * 
   * @element-type Afiliacion
   */
  private Vector  programas;
}