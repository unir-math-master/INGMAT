import java.util.Vector;
import java.util.Date;

public class TarjetaCliente {

  private boolean valida;

  private Date validaDesde;

  private Date caducidad;

  private Color color;

  private String nombreImpreso;

    private Cliente propietario;
    /**
   * 
   * @element-type Transaccion
   */
  private Vector  transacciones;
    private Afiliacion laAfiliacion;

  public boolean tarjetaValida() {
  return false;
  }
}