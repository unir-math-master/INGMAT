import java.util.Vector;

public class Servicio {

  private boolean condicion;

  private int puntosAcumulados;

  private int puntosCanjeados;

  private String descripcion;

    private ProgramaSocios elProgramaSocios;
    private NivelServicio nivel;
    /**
   * 
   * @element-type Transaccion
   */
  private Vector  transacciones;
}