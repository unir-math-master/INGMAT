

public class Afiliacion {

  private Date fecha;
    /**
   * 
   * los siguientes atributos son para modelar la asociacion a la que  sustituye
   */
    private Cliente elcliente;
    private ProgramaFidelizacion elprograma
  private TarjetaCliente  tarjeta;
    /**
   * 
   * 
   */
  private NivelServicio nivelActual;
    /**
   * 
   * 
   */
  private CuentaFidelizacion  cuenta;

  public void inscribirse(Cliente c) {
  }

  public boolean comprobarInscripcion(Cliente c) {
  return false;
  }
}