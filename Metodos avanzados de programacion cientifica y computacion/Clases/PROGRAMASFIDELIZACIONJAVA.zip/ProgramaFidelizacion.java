import java.util.Vector;

public class ProgramaFidelizacion {

    /**
   * 
   * @element-type ProgramaSocios
   */
  private Vector  socios;
    /**
   * 
   * @element-type NivelServicio
   */
  private Vector  niveles;
    /**
   * 
   * @element-type Afiliacion
   */
  private Vector  clientes;

  public void inscribirse(Cliente c) {
  }

  public boolean comprobarInscripcion(Cliente c) {
  return false;
  }
}