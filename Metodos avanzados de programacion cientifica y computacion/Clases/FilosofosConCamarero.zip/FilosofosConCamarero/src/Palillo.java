/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mluisadiez
 */
import java.util.*;
public class Palillo {
    private Random random = new Random();
      private int id;
     private boolean libre = true;
    
    /**
     * Constructo del monitor  Palillo
     * 
     * @
     */
    public Palillo(int id){
        this.id = id;
    }
    
   
    /**
     * Método para coger el palillo
     * 
     * 
     */
    public synchronized boolean cogerPalillo(int id_f) throws InterruptedException{
        while(!libre) 
            this.wait();
        System.out.println("El Filósofo " + (id_f+1) + " coge el palillo " + (id+1));
        
        libre = false;
        return true;
    }
  
    /**
     * Método para dejar el palillo
     * 
     * 
     */
    public synchronized void soltarPalillo(int id_f) throws InterruptedException {
        libre = true;
        System.out.println("El Filósofo " + (id_f+1) + " deja el  palillo " + (id+1));
        
         this.notify();
    }
}
