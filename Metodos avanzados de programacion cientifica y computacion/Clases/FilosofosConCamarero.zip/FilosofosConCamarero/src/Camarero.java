/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author mluisadiez
 */
public class Camarero {
    private int numFilosofos = 0; // Es el número de comensales total de filósofos menos 1
    
    /**
     * @param id_f ID del filósofo
     * 
     */
    public synchronized void darPermisoEntrada(int id_f) throws InterruptedException{
        System.out.println("El Filósofo " + (id_f+1) + " pide permiso para entrar  en el comedor " );
        while(numFilosofos==4){ // Si no hay comensales libres espera
            this.wait();
        } 
        
        
        numFilosofos++; 
    }
    
    /**
     * 
     * @param id_f ID del fiósofo
     * @throws InterruptedException Posibles errores
     */
    public synchronized void invitarSalidaFilosofo(int id_f) throws InterruptedException{
        numFilosofos--; 
        System.out.println("El Filósofo " + (id_f+1) + " ha salido del comedor " );
     
        
        this.notify(); //Pone disponible al siguiente
    }
}
