/*********************************************************
 *     Clase que permite crear los fil�sofos que         *
 * participan en la tertulia.                            *
 *********************************************************/
 
 
 import java.util.*;
 
 public class Filosofo extends Thread {
   
    private Random random = new Random();
   
    private int id;
   
    private Palillo izdo, dcho;
   
        
  
    /** 
     * 
     *
     */
    public Filosofo(int id, Palillo dcho, Palillo izdo){
        // Se asignan los valores recibidos a las variables
        this.id = id;
        this.dcho = dcho;
        this.izdo = izdo;
        
        
    }
    
    /**
     * Método que se ejecuta indefinidamente
     */
    @Override
    public void run(){
        while(true){ // Se repite infinitamente While
            
            try { // try / catch
                
                FilosofosConCamarero.camarero.darPermisoEntrada(id);
                System.out.println("El Filósofo " + (id+1) +" ha entrado en el comedor");
                
                dcho.cogerPalillo(id);
                izdo.cogerPalillo(id);
                 
               
                // Si ha conseguido los dos palillos come
                    
                             
                System.out.println("El Filósofo " + (id+1) + " está comiendo.");
                    
                    
                    try {
                        sleep(random.nextInt(1000) + 500);
                    } catch (InterruptedException ex) {
                        System.out.println("Error. " + ex.toString());
                      } 
                        
                
                izdo.soltarPalillo(id);
                   
                dcho.soltarPalillo(id);
                
                FilosofosConCamarero.camarero.invitarSalidaFilosofo(id);
                
                
                    
              //  El filoso piensa
                 System.out.println("El Filósofo " + (id+1) + " está pensando.");
                try {
                    Filosofo.sleep(random.nextInt(1000) + 100);
                } catch (InterruptedException ex) {
                    System.out.println("Se ha producido una interrupción" + ex.toString());
                    throw new InterruptedException();
                 }
               } catch (InterruptedException ex) {
                ex.printStackTrace();
                System.err.println("\"La cena ha terminado ");
               
            } // Fin del try / catch
            
           
            
        }  // Fin de Se repite infinitamente While

        
    }
}