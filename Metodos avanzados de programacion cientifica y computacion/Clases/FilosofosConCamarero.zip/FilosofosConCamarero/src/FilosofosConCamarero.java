/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author mluisadiez
 */
public class FilosofosConCamarero {

    public static Palillo[] palillos=new Palillo[5];
    public static Filosofo[] filosofos=new Filosofo[5];
    public static Camarero camarero=new Camarero();
	 public static void main (String args[]){
            try{
                   
                for (int  i=0; i<5; i++){
                    palillos[i]=new Palillo(i);
                   
                }
                for (int  i=0; i<5; i++){
                   int  n=(i+1)%5;
                   int numFilosofo=i+1;
                   System.out.println("Se crea el filosofo "+ numFilosofo);
                
                    filosofos[i]=new Filosofo(i,palillos[i],palillos[n]);
                   
                }
                filosofos[0].start();filosofos[1].start();filosofos[2].start();filosofos[3].start();filosofos[4].start();
                filosofos[0].join();filosofos[1].join();filosofos[2].join();filosofos[3].join();filosofos[4].join();
            
         }catch (InterruptedException e){
             
         }
         }
}
                
        
   


