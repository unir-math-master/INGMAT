%Grafica del problema 7
clear;

x = 0:0.1:10

y = (1/4*pi) + (cos(x/4)/(8*sqrt(2))) + (sin(x/2)/4)

plot(x,y)
